<template>
    <input
      type="text"
      placeholder="Ingrese País"
      class="form-control my-3"
      v-model="texto"
      @input="handleInput"
    />
  </template>
  <script>
  import { ref, watch, computed } from "vue";
  import { useStore } from "vuex";
  
  export default {
    setup() {
      const texto = ref("");
      const store = useStore();
      const countries = computed(() => store.getters.countries);
  
      let typingTimer = null;
  
      const handleInput = () => {
        clearTimeout(typingTimer);
  
        typingTimer = setTimeout(() => {
          store.dispatch("filtroNombre", texto.value);
        }, 5000);
      };
  
      return { texto, countries, handleInput };
    },
  };
  </script> 