<template>
    <div class="card h-100 shadow p-3 mb-5 bg-body rounded">
      <div class="card-body">
        <h5 class="card-title">{{pais.name}}</h5>
        <p class="text-center">
          <img :src="pais.flag" :alt="`Bandera-${pais.name}`" :title="`Bandera-${pais.name}`" class="img-thumbnail rounded mx-auto d-block">
        </p>
        <div class="card-text">
          <div class="row mb-4">
            <div class="col-sm-6">
              <small><u>Pais:</u></small> <span class="badge rounded-pill bg-success text-white">{{pais.nativeName}}</span>
            </div>
            <div class="col-sm-6">
              <small><u>Capital:</u></small> <span class="badge rounded-pill bg-success text-white">{{pais.capital}}</span>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <small><u>Poblacion:</u></small> <span class="badge rounded-pill bg-success text-white">{{numeroFormato(pais.population)}}</span>
            </div>
            <div class="col">
              <small><u>Continente:</u></small> <span class="badge rounded-pill bg-success text-white">{{pais.region}}</span>
            </div>
          </div>
        </div>
        <button @click="verDetalle(pais)" class="btn btn-primary">Ver detalle</button>
      </div>
      <!-- Modal -->
      <div class="modal fade" id="detalleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">{{pais.name}}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p><strong>Nombre nativo:</strong> {{pais.nativeName}}</p>
              <p><strong>Capital:</strong> {{pais.capital}}</p>
              <p><strong>Población:</strong> {{numeroFormato(pais.population)}}</p>
              <p><strong>Continente:</strong> {{pais.region}}</p>
              <p><strong>Subregión:</strong> {{pais.subregion}}</p>
              <p><strong>Código ISO:</strong> {{pais.alpha2Code}}</p>
              <p><strong>Dominio de internet:</strong> {{pais.topLevelDomain}}</p>
              <p><strong>Moneda:</strong> {{pais.currencies[0].name}} ({{pais.currencies[0].code}})</p>
              <p><strong>Idiomas:</strong> {{pais.languages.map(lang => lang.name).join(', ')}}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  <script>
  import axios from 'axios';
  
  export default {
    props: ['pais'],
    setup() {
      const numeroFormato = (num) => {
        return new Intl.NumberFormat("de-DE").format(num)
      }
  
      const verDetalle = async (pais) => {
        try {
          const respuesta = await axios.get(`https://restcountries.com/v2/alpha/${pais.alpha2Code}`)
          const paisDetalle = respuesta.data
          console.log(paisDetalle)
          // Aquí se muestra la información en la ventana modal
          const detalleModal = new bootstrap.Modal(document.getElementById('detalleModal'))
          detalleModal.show()
          // Actualizar el título de la ventana modal con el nombre del país
          document.querySelector('#detalleModal .modal-title').textContent = pais.name
          // Actualizar el contenido de la ventana modal con la información del país
          document.querySelector('#detalleModal .modal-body').innerHTML = `
            <p><strong>Nombre nativo:</strong> ${paisDetalle.nativeName}</p>
            <p><strong>Capital:</strong> ${paisDetalle.capital}</p>
            <p><strong>Población:</strong> ${numeroFormato(paisDetalle.population)}</p>
            <p><strong>Continente:</strong> ${paisDetalle.region}</p>
            <p><strong>Subregión:</strong> ${paisDetalle.subregion}</p>
            <p><strong>Código ISO:</strong> ${paisDetalle.alpha2Code}</p>
            <p><strong>Dominio de internet:</strong> ${paisDetalle.topLevelDomain}</p>
            <p><strong>Moneda:</strong> ${paisDetalle.currencies[0].name} (${paisDetalle.currencies[0].code})</p>
            <p><strong>Idiomas:</strong> ${paisDetalle.languages.map(lang => lang.name).join(', ')}</p>
          `
        } catch (error) {
          console.log(error)
        }
      }
  
      return { numeroFormato, verDetalle }
    }
  }
  </script>
  