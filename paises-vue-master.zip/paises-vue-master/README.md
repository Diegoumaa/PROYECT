
## Instalar dependencias
- Ejecutar en terminal comando: `npm install`.

## Iniciar proyecto
- Ejecutar en terminal el comando `npm run serve` e introducir en el navegador `http://localhost:8080/`.

